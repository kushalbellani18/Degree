############## Type Checking ############
python3 type_checking.py expr

where, expr combine operator, numberic, and string.

For example, 
python3 type_checking.py a+b*3 # Return ERROR

python3 type_checking.py 4+5*2 # return TRUE

############## Intermediate Code #############
python3 intermediate_code.py expr

where expr same above but only string, not number

############# Code Optimization ##############
python3 code_optimization.py file-path

where file is given in file data, you can create it.

For example, python3 code_optimization.py file/hi.txt

############# Code Generation #############
python3 code_generation.py expr

Where expr same as above, only string, not number. It will return Assembly langauge.
